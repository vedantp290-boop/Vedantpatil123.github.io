SAGAR MELTING CENTER — PRO WEBSITE
=====================================

Files:
- index.html — complete responsive website

Features:
- Sagar Melting Center branding and contact details
- Customer report creation
- Automatic melting loss and fine-gold calculation
- Unique SMC report IDs
- Save reports in browser localStorage
- Find/open saved reports by ID
- Professional print/PDF-ready certificate
- Mobile responsive layout
- Business process and verification sections

HOW TO USE
1. Extract the ZIP.
2. Open index.html in Chrome, Safari or Edge.
3. Go to "Create Customer Report".
4. Enter customer name, phone, item, received weight, melted weight and purity.
5. Click Save Report.
6. Click Print / Save PDF to make a customer copy.

IMPORTANT
This is a ready-to-use front-end website and local demo system. Reports are stored only in the browser/device used to create them. It does NOT yet provide secure cloud storage, online customer accounts, real QR verification, or multi-device synchronization.

For a real business deployment, connect it to a secure backend/database and hosting, and add authentication/authorization, encrypted storage, audit logs, backups, and server-side report verification.
